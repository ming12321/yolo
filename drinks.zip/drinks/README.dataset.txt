# drinks > 2025-04-02 10:40pm
https://universe.roboflow.com/topic-yakb4/drinks-gpvgq

Provided by a Roboflow user
License: CC BY 4.0

